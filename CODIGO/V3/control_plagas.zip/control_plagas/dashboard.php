<?php   
session_start();
include('conexion.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];

    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE username=?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        if (password_verify($clave, $user['password'])) {
            $_SESSION['usuario'] = $usuario;
            $_SESSION['usuario_id'] = $user['id'];
        } else {
            header("Location: index.php?error=Usuario o contraseña incorrectos");
            exit();
        }
    } else {
        header("Location: index.php?error=Usuario o contraseña incorrectos");
        exit();
    }
}

if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Panel de Control</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background-color: #f8f9fa; /* Color de fondo suave */
        }
        .navbar-brand {
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        .navbar-brand i {
            margin-right: 8px;
            font-size: 1.5em;
        }
        .container {
            padding-top: 120px; /* Ajuste para el navbar fijo */
            padding-bottom: 40px;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            background-color: #ffffff;
            padding: 20px;
        }
        .card-header {
            background-color: #0d6efd; /* Color primario de Bootstrap */
            color: white;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
            font-size: 1.25em;
            padding: 15px 20px;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
            transition: background-color 0.3s ease;
        }
        .btn-secondary:hover {
            background-color: #5c636a;
            border-color: #565e64;
        }
        .form-label {
            font-weight: 500;
            margin-bottom: 5px;
        }
        /* Estilos para modo oscuro */
        html[data-bs-theme="dark"] body {
            background-color: #212529 !important;
        }
        html[data-bs-theme="dark"] .navbar {
            background-color: #343a40 !important;
        }
        html[data-bs-theme="dark"] .card {
            background-color: #343a40;
            color: #f8f9fa;
        }
        html[data-bs-theme="dark"] .card-header {
            background-color: #0a58ca !important;
        }
        html[data-bs-theme="dark"] .form-control {
            background-color: #495057;
            color: #f8f9fa;
            border-color: #6c757d;
        }
        html[data-bs-theme="dark"] .form-control::placeholder {
            color: #ced4da;
        }
        html[data-bs-theme="dark"] .form-select {
            background-color: #495057;
            color: #f8f9fa;
            border-color: #6c757d;
        }
        html[data-bs-theme="dark"] .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%); /* Makes close button visible on dark backgrounds */
        }
        html[data-bs-theme="dark"] .alert-success {
            background-color: #1a5e30;
            color: #d1e7dd;
            border-color: #144a24;
        }
        html[data-bs-theme="dark"] .alert-danger {
            background-color: #5c1f24;
            color: #f8d7da;
            border-color: #49171b;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <i class="bi bi-bug-fill"></i> Control de Plagas
        </a>
        <div class="d-flex">
            <a href="logout.php" class="btn btn-outline-light ms-2">
                <i class="bi bi-box-arrow-right"></i> Cerrar sesión
            </a>
        </div>
    </div>
</nav>
<div class="container">
    <h2 class="text-center mb-4">Bienvenido, <span class="text-primary"><?php echo $_SESSION['usuario']; ?></span>!</h2>

    <?php
    // Mostrar mensajes de éxito o error si vienen de crear_reporte.php
    if (isset($_GET['success']) && $_GET['success'] === 'reporte_creado') {
        echo '<div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <div>Reporte creado exitosamente.</div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
    }
    if (isset($_GET['error'])) {
        $errorMessage = "";
        if ($_GET['error'] === 'otro_vacio') {
            $errorMessage = "Debe especificar el tipo de plaga cuando selecciona 'Otro'.";
        } elseif ($_GET['error'] === 'creacion_fallida') {
            $errorMessage = "Error al crear el reporte. Por favor, inténtelo de nuevo.";
        } else {
            $errorMessage = "Ha ocurrido un error: " . htmlspecialchars($_GET['error']);
        }
        echo '<div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <div>' . $errorMessage . '</div>
                <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
    }
    ?>

    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-header text-center">
            <i class="bi bi-file-earmark-plus-fill me-2"></i> Crear Nuevo Reporte Técnico
        </div>
        <div class="card-body">
            <form method="POST" action="crear_reporte.php">
                <div class="mb-3">
                    <label for="fecha" class="form-label"><i class="bi bi-calendar-check me-1"></i> Fecha:</label>
                    <input type="date" name="fecha" id="fecha" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="ubicacion" class="form-label"><i class="bi bi-geo-alt-fill me-1"></i> Ubicación:</label>
                    <input type="text" name="ubicacion" id="ubicacion" class="form-control" placeholder="Ej: Calle Principal 123, Ciudad" required>
                </div>
                <div class="mb-3">
                    <label for="tipo_plaga" class="form-label"><i class="bi bi-bug me-1"></i> Tipo de Plaga:</label>
                    <select class="form-control" id="tipo_plaga" name="tipo_plaga" onchange="mostrarCampoOtro()" required>
                        <option value="">Seleccione un tipo de plaga</option> <option value="Roedores">Roedores</option>
                        <option value="Insectos voladores">Insectos voladores</option>
                        <option value="Insectos rastreros">Insectos rastreros</option>
                        <option value="Otro">Otro</option>
                    </select>
                </div>
                <div class="mb-3" id="campo_otro_plaga" style="display: none;">
                    <label for="otra_plaga" class="form-label"><i class="bi bi-pencil-fill me-1"></i> Especificar Otro:</label>
                    <input type="text" class="form-control" id="otra_plaga" name="otra_plaga" placeholder="Ej: Termitas, Caracoles, etc.">
                </div>
                <div class="mb-3">
                    <label for="descripcion" class="form-label"><i class="bi bi-file-earmark-text-fill me-1"></i> Descripción:</label>
                    <textarea name="descripcion" id="descripcion" class="form-control" rows="4" placeholder="Detalle la situación de la plaga, extensión, recomendaciones, etc." required></textarea>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-3">
                    <i class="bi bi-save-fill me-2"></i> Guardar Reporte
                </button>
            </form>
            <div class="text-center mt-3">
                <a href="ver_reportes.php" class="btn btn-secondary w-100">
                    <i class="bi bi-list-columns-reverse me-2"></i> Ver Reportes Existentes
                </a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function mostrarCampoOtro() {
    var tipoPlagaSelect = document.getElementById("tipo_plaga");
    var campoOtroPlagaDiv = document.getElementById("campo_otro_plaga");
    var otraPlagaInput = document.getElementById("otra_plaga");

    if (tipoPlagaSelect.value === "Otro") {
        campoOtroPlagaDiv.style.display = "block"; // Muestra el campo
        otraPlagaInput.setAttribute("required", ""); // Hace el campo requerido
    } else {
        campoOtroPlagaDiv.style.display = "none";  // Oculta el campo
        otraPlagaInput.removeAttribute("required"); // Quita el atributo requerido
        otraPlagaInput.value = ""; // Limpia el valor cuando se oculta
    }
}

// Para el dismiss de las alertas de Bootstrap
var alertList = document.querySelectorAll('.alert');
alertList.forEach(function (alert) {
  new bootstrap.Alert(alert)
});
</script>
</body>
</html>

// Para el dismiss de las alertas de Bootstrap
var alertList = document.querySelectorAll('.alert');
alertList.forEach(function (alert) {
  new bootstrap.Alert(alert)
})
</script>
</body>
</html>