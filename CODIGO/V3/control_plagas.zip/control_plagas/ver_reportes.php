<?php
session_start();
include('conexion.php');
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit();
}

// Consulta original (ajusta si tu consulta es diferente)
$result = $conn->query("SELECT id, fecha, ubicacion, tipo_plaga, descripcion FROM reportes");
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Reportes Técnicos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
</head>
<body style="background: #f8f9fa;">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="dashboard.php"><i class="bi bi-bug"></i> TKC DESINFECCIONES</a>
        <a class="btn btn-outline-light ms-auto" href="logout.php"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a>
    </div>
</nav>
<div class="container" style="margin-top: 100px;">
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-3"><i class="bi bi-file-earmark-text"></i> Reportes Técnicos</h2>
            <a href="dashboard.php" class="btn btn-primary mb-3"><i class="bi bi-plus-circle"></i> Nuevo Reporte</a>
        </div>
    </div>
    <?php if ($result && $result->num_rows > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle shadow-sm bg-white rounded">
                <thead class="table-dark">
                    <tr>
                        <th>Fecha</th>
                        <th>Ubicación</th>
                        <th>Tipo de Plaga</th>
                        <th>Descripción</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['fecha']); ?></td>
                        <td><?php echo htmlspecialchars($row['ubicacion']); ?></td>
                        <td><?php echo htmlspecialchars($row['tipo_plaga']); ?></td>
                        <td><?php echo htmlspecialchars($row['descripcion']); ?></td>
                        <td>
                            <a href="exportar_pdf.php?id=<?php echo $row['id']; ?>" target="_blank" class="btn btn-outline-danger btn-sm" title="Exportar PDF">
                                <i class="bi bi-file-earmark-pdf"></i>
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="alert alert-info text-center">
            <i class="bi bi-info-circle"></i> No hay reportes técnicos registrados aún.
        </div>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
