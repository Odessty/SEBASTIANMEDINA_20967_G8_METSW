<?php
session_start();
if (isset($_SESSION['usuario'])) {
    header("Location: dashboard.php");
    exit();
}

// Ejemplo de mensajes (puedes adaptarlo según tu lógica)
$mensaje_exito = isset($_GET['exito']) ? htmlspecialchars($_GET['exito']) : '';
$mensaje_error = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : '';
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Ingreso al Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background-color: #e9ecef; /* Un gris claro suave */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; /* Ocupa al menos el alto de la ventana */
            margin: 0;
            flex-direction: column;
        }
        .navbar-brand {
            font-weight: bold;
            display: flex;
            align-items: center;
        }
        .navbar-brand i {
            margin-right: 8px;
            font-size: 1.5em;
        }
        .container {
            flex-grow: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.15); /* Sombra más pronunciada */
            background-color: #ffffff;
            padding: 20px;
            width: 100%; /* Asegura que ocupe el ancho del col-md-6/col-lg-5 */
        }
        .card-body {
            padding: 30px;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
            transition: background-color 0.3s ease;
        }
        .btn-secondary:hover {
            background-color: #5c636a;
            border-color: #565e64;
        }
        .form-label {
            font-weight: 500;
            margin-bottom: 5px;
        }
        /* Estilos para modo oscuro */
        html[data-bs-theme="dark"] body {
            background-color: #2c3034 !important;
        }
        html[data-bs-theme="dark"] .navbar {
            background-color: #343a40 !important;
        }
        html[data-bs-theme="dark"] .card {
            background-color: #343a40;
            color: #f8f9fa;
        }
        html[data-bs-theme="dark"] .form-control {
            background-color: #495057;
            color: #f8f9fa;
            border-color: #6c757d;
        }
        html[data-bs-theme="dark"] .form-control::placeholder {
            color: #ced4da;
        }
        html[data-bs-theme="dark"] .alert-success {
            background-color: #1a5e30;
            color: #d1e7dd;
            border-color: #144a24;
        }
        html[data-bs-theme="dark"] .modal-content {
            background-color: #343a40;
            color: #f8f9fa;
        }
        html[data-bs-theme="dark"] .modal-header {
            background-color: #dc3545 !important;
            border-bottom: 1px solid #dc3545;
        }
        html[data-bs-theme="dark"] .modal-footer {
            border-top: 1px solid #495057;
        }
        html[data-bs-theme="dark"] .btn-close-white {
            filter: invert(1) grayscale(100%) brightness(200%);
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">
            <i class="bi bi-activity"></i> TKC DESINFECCIONES
        </a>
    </div>
</nav>
<div class="container">
    <div class="row justify-content-center w-100">
        <div class="col-md-6 col-lg-5">
            <div class="card shadow-lg border-0">
                <div class="card-body">
                    <h3 class="text-center mb-4 text-secondary">Inicia Sesión para Continuar</h3>
                    <?php if ($mensaje_exito): ?>
                        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
                            <i class="bi bi-check-circle-fill me-2"></i>
                            <div><?php echo $mensaje_exito; ?></div>
                            <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Cerrar"></button>
                        </div>
                    <?php endif; ?>
                    <?php if ($mensaje_error): ?>
                        <div class="modal fade" id="errorModal" tabindex="-1" aria-labelledby="errorModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                              <div class="modal-header bg-danger text-white">
                                <h5 class="modal-title" id="errorModalLabel"><i class="bi bi-exclamation-triangle-fill me-2"></i> Error de Acceso</h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                              </div>
                              <div class="modal-body">
                                <p><?php echo $mensaje_error ? $mensaje_error : 'Usuario o contraseña incorrectos.'; ?></p>
                              </div>
                              <div class="modal-footer">
                                <a href="registrar.php" class="btn btn-outline-primary"><i class="bi bi-person-plus-fill me-2"></i> Registrarse</a>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="bi bi-x-circle-fill me-2"></i> Cerrar</button>
                              </div>
                            </div>
                          </div>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="dashboard.php">
                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-person-fill me-1"></i> Usuario:</label>
                            <input type="text" name="usuario" class="form-control" placeholder="Ingresa tu usuario" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><i class="bi bi-lock-fill me-1"></i> Contraseña:</label>
                            <input type="password" name="clave" class="form-control" placeholder="Ingresa tu contraseña" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 mt-3">
                            <i class="bi bi-box-arrow-in-right me-2"></i> Ingresar
                        </button>
                        <p class="text-center mt-4 mb-2"><a href="registrar.php" class="text-decoration-none text-info">¿No tienes cuenta? Regístrate aquí</a></p>
                        <p class="text-center mt-3">
                            <button type="button" class="btn btn-outline-secondary" onclick="toggleTheme()">
                                <i class="bi bi-moon-fill me-2" id="theme-icon"></i> <span id="theme-text">Modo Oscuro</span>
                            </button>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function toggleTheme() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-bs-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-bs-theme', newTheme);

    const themeIcon = document.getElementById('theme-icon');
    const themeText = document.getElementById('theme-text');
    if (newTheme === 'dark') {
        themeIcon.classList.remove('bi-moon-fill');
        themeIcon.classList.add('bi-sun-fill');
        themeText.textContent = 'Modo Claro';
    } else {
        themeIcon.classList.remove('bi-sun-fill');
        themeIcon.classList.add('bi-moon-fill');
        themeText.textContent = 'Modo Oscuro';
    }
}

// Set initial theme icon and text based on current theme
document.addEventListener('DOMContentLoaded', function() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-bs-theme');
    const themeIcon = document.getElementById('theme-icon');
    const themeText = document.getElementById('theme-text');

    if (themeIcon && themeText) {
        if (currentTheme === 'dark') {
            themeIcon.classList.remove('bi-moon-fill');
            themeIcon.classList.add('bi-sun-fill');
            themeText.textContent = 'Modo Claro';
        } else {
            themeIcon.classList.remove('bi-sun-fill');
            themeIcon.classList.add('bi-moon-fill');
            themeText.textContent = 'Modo Oscuro';
        }
    }

    <?php if ($mensaje_error): ?>
    var errorModal = new bootstrap.Modal(document.getElementById('errorModal'));
    errorModal.show();
    <?php endif; ?>
});
</script>
</body>
</html>