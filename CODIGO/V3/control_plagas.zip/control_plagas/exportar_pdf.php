<?php
ob_start(); // ← IMPORTANTE: inicia el buffer

require_once('tcpdf/tcpdf.php');
include('conexion.php');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $conn->prepare("SELECT fecha, ubicacion, tipo_plaga, descripcion FROM reportes WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($fecha, $ubicacion, $tipo_plaga, $descripcion);
$stmt->fetch();
$stmt->close();

// Crear PDF
$pdf = new TCPDF();
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('TKC DESINFECCIONES');
$pdf->SetTitle('Reporte Técnico');
$pdf->SetMargins(20, 30, 20);
$pdf->AddPage();

// Encabezado personalizado
$html = '
<style>
    h1 { color: #0d6efd; font-size: 24px; }
    .info { font-size: 14px; margin-bottom: 10px; }
    .label { font-weight: bold; color: #212529; }
    .valor { color: #495057; }
    .desc { background-color: #f8f9fa; padding: 10px; border-radius: 5px; }
</style>
<h1>Reporte Técnico</h1>
<hr>
<div class="info"><span class="label">Fecha:</span> <span class="valor">'.htmlspecialchars($fecha).'</span></div>
<div class="info"><span class="label">Ubicación:</span> <span class="valor">'.htmlspecialchars($ubicacion).'</span></div>
<div class="info"><span class="label">Tipo de Plaga:</span> <span class="valor">'.htmlspecialchars($tipo_plaga).'</span></div>
<div class="info label">Descripción:</div>
<div class="desc">'.nl2br(htmlspecialchars($descripcion)).'</div>
<br><br>
<div style="text-align:right; font-size:12px; color:#888;">Generado por TKC DESINFECCIONES</div>
';

$pdf->writeHTML($html, true, false, true, false, '');
ob_end_clean(); // ← IMPORTANTE: limpia cualquier salida antes de enviar el PDF

$pdf->Output('reporte_tecnico.pdf', 'I');
?>
