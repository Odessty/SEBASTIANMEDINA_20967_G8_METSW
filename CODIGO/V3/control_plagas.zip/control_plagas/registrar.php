<?php
session_start();
include('conexion.php');

$mensaje_exito = isset($_GET['exito']) ? htmlspecialchars($_GET['exito']) : '';
$mensaje_error = isset($_GET['error']) ? htmlspecialchars($_GET['error']) : '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario']);
    $clave = $_POST['clave'];
    $clave2 = $_POST['clave2'];

    // Validar que las contraseñas coincidan
    if ($clave !== $clave2) {
        header("Location: registrar.php?error=Las contraseñas no coinciden.");
        exit();
    }

    // Validar mayúsculas y minúsculas en usuario
    if (!preg_match('/[A-Z]/', $usuario) || !preg_match('/[a-z]/', $usuario)) {
        header("Location: registrar.php?error=El usuario debe contener al menos una letra mayúscula y una minúscula.");
        exit();
    }

    // Validar mayúsculas y minúsculas en contraseña
    if (!preg_match('/[A-Z]/', $clave) || !preg_match('/[a-z]/', $clave)) {
        header("Location: registrar.php?error=La contraseña debe contener al menos una letra mayúscula y una minúscula.");
        exit();
    }

    // Validar si el usuario ya existe
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE username = ?");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        header("Location: registrar.php?error=El nombre de usuario ya está registrado.");
        exit();
    }
    $stmt->close();

    // Si todo está bien, registrar el usuario
    $clave_hash = password_hash($clave, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $usuario, $clave_hash);
    if ($stmt->execute()) {
        header("Location: registrar.php?exito=Usuario registrado con éxito.");
    } else {
        header("Location: registrar.php?error=Error al registrar el usuario.");
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="es" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="background: #f8f9fa;">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">TKC DESINFECCIONES</a>
    </div>
</nav>
<div class="container" style="margin-top: 110px;">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card shadow-lg border-0">
                <div class="card-body">
                    <h2 class="text-center mb-3">Crear nueva cuenta</h2>
                    <p class="text-center text-muted mb-4">Completa el formulario para registrarte en el sistema.</p>
                    <?php if ($mensaje_exito): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo $mensaje_exito; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
                        </div>
                    <?php endif; ?>
                    <?php if ($mensaje_error): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo $mensaje_error; ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="registrar.php">
                        <div class="mb-3">
                            <label class="form-label">Usuario </label>
                            <input type="text" name="usuario" class="form-control" placeholder="Debe contener al menos una mayúscula" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Contraseña</label>
                            <input type="password" name="clave" class="form-control" placeholder="La contraseña debe contener una mayúscula y una minúscula" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirmar contraseña</label>
                            <input type="password" name="clave2" class="form-control" placeholder="Repite la contraseña" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Registrarse</button>
                        <p class="text-center mt-3"><a href="index.php">¿Ya tienes cuenta? Inicia sesión</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
