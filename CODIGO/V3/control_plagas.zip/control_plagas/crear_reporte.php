<?php
session_start();
include('conexion.php');

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit();
}

// Obtener los datos del formulario
$fecha = $_POST['fecha'];
$ubicacion = $_POST['ubicacion'];
$tipo_plaga_seleccionada = $_POST['tipo_plaga']; // El valor del select
$descripcion = $_POST['descripcion'];

// Variable para almacenar el tipo de plaga final a insertar
$tipo_plaga_final = "";

// Verificar si se seleccionó "Otro"
if ($tipo_plaga_seleccionada === "Otro") {
    // Si es "Otro", obtenemos el valor del campo de texto "otra_plaga"
    // Asegúrate de que este campo tenga el atributo 'name="otra_plaga"' en tu HTML
    if (isset($_POST['otra_plaga']) && !empty($_POST['otra_plaga'])) {
        $tipo_plaga_final = $_POST['otra_plaga'];
    } else {
        // Manejar el caso en que "Otro" fue seleccionado pero el campo de especificación está vacío
        // Podrías redirigir con un mensaje de error o asignar un valor predeterminado
        // Por ahora, redirigiremos de vuelta al dashboard (o a una página de error)
        header("Location: dashboard.php?error=otro_vacio");
        exit();
    }
} else {
    // Si no es "Otro", usamos directamente el valor del select
    $tipo_plaga_final = $tipo_plaga_seleccionada;
}

// Preparar y ejecutar la consulta SQL con el tipo de plaga final
$stmt = $conn->prepare("INSERT INTO reportes (usuario_id, fecha, ubicacion, tipo_plaga, descripcion) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("issss", $_SESSION['usuario_id'], $fecha, $ubicacion, $tipo_plaga_final, $descripcion);

if ($stmt->execute()) {
    header("Location: dashboard.php?success=reporte_creado");
} else {
    // Manejar errores en la inserción
    // Puedes loguear el error o redirigir con un mensaje de error
    error_log("Error al insertar reporte: " . $stmt->error);
    header("Location: dashboard.php?error=creacion_fallida");
}

$stmt->close();
$conn->close();
exit();
?>